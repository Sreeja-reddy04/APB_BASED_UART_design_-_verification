package test_pkg;

  import uvm_pkg::*;
  `include "uvm_macros.svh"


    `include "apb_xtn.sv"
    `include "uart_xtn.sv"

    `include "apb_config.sv"
    `include "uart_config.sv"
    `include "env_config.sv"

  // APB agent files
  `include "apb_seq.sv"
  `include "apb_seqr.sv"
  `include "apb_drv.sv"
  `include "apb_mon.sv"
  `include "apb_agent.sv"
  `include "apb_agent_top.sv"

  // UART agent files
  `include "uart_seq.sv"
  `include "uart_seqr.sv"
  `include "uart_drv.sv"
  `include "uart_mon.sv"
  `include "uart_agent.sv"
  `include "uart_agent_top.sv"

  // TB files"
  `include "sb.sv"
  `include "env.sv"


  // Test
  `include "test.sv"

endpackage

