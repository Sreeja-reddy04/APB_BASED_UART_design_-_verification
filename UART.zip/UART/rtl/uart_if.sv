interface uart_if(input bit clk2);

        logic Presetn;
        logic [31:0] Paddr;
        bit Psel;
        bit Pwrite;
        bit Penable;
        logic [31:0] Pwdata;
        logic [31:0] Prdata;
        logic Pready;
        logic Pslverr;
        bit IRQ;
        logic tx;
        logic rx;
        logic baud_o;
endinterface

