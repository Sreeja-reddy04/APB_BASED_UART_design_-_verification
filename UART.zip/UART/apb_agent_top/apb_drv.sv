class apb_drv extends uvm_driver#(apb_xtn);

        `uvm_component_utils(apb_drv)

        function new(string name = "",uvm_component parent);
                super.new(name,parent);
        endfunction

        apb_conf apb_conf_h;
        virtual apb_if.apb_drv_mp vif;

        function void build_phase(uvm_phase phase);
                super.build_phase(phase);
                if(!uvm_config_db#(apb_conf)::get(this, "", "apb_conf", apb_conf_h))
                        `uvm_fatal("APB_DRV", "Failed to get APB configuration")
        endfunction

        function void connect_phase(uvm_phase phase);
                super.connect_phase(phase);
                vif = apb_conf_h.vif ;
        endfunction

        task run_phase(uvm_phase phase);
                @(vif.apb_drv_cb);
                vif.apb_drv_cb.PRESETn <= 0;
                @(vif.apb_drv_cb);
                vif.apb_drv_cb.PRESETn <= 1;

                forever begin
                        seq_item_port.get_next_item(req);
                        `uvm_info("APB_DRV", "\nReceived a transaction from sequence", UVM_MEDIUM)
                        req.print();
                        drive(req);
                        seq_item_port.item_done();
                end
        endtask

         task drive(apb_xtn req);

                @(vif.apb_drv_cb);
                vif.apb_drv_cb.PADDR <= req.PADDR;
                vif.apb_drv_cb.PWDATA <= req.PWDATA;
                vif.apb_drv_cb.PWRITE <= req.PWRITE;

                vif.apb_drv_cb.PENABLE <= 0;
                vif.apb_drv_cb.PSEL <= 1;

                @(vif.apb_drv_cb);
                vif.apb_drv_cb.PENABLE <= 1;

                @(vif.apb_drv_cb);

                while(!vif.apb_drv_cb.PREADY)                   // we declared pready in driver as input  we can use pready ready in vif
                        @(vif.apb_drv_cb);            // waits for the slave to be ready and moves to next line if asserted

                if(req.PADDR == 32'h8 && req.PWRITE == 0)
                begin                                                 // IIR register
                        while(vif.apb_drv_cb.IRQ==0)                    //wait for the interrupt to be asserted
                                @(vif.apb_drv_cb);

                        req.iir = vif.apb_drv_cb.PRDATA;

                        /*rsp = req.clone(); //declare handle when u use it
                        rsp.set_id_info(req);
                        rsp.PRDATA = vif.apb_drv_cb.PRDATA;

                        seq_item_port.put_response(rsp); */
                        seq_item_port.put_response(req);
                end
            //    @(vif.apb_drv_cb);

                vif.apb_drv_cb.PENABLE <= 0;
                vif.apb_drv_cb.PSEL <= 0;

        endtask
endclass
