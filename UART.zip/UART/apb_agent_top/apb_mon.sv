class apb_mon extends uvm_monitor;
        `uvm_component_utils(apb_mon)
        apb_conf apb_conf_h;
        virtual apb_if.apb_mon_mp vif;
        uvm_analysis_port#(apb_xtn) mon_port;
                 apb_xtn xtn;

        function new(string name = "",uvm_component parent);
                super.new(name,parent);
                mon_port = new("mon_port", this);
        endfunction

        function void build_phase(uvm_phase phase);
                super.build_phase(phase);
                if(!uvm_config_db#(apb_conf)::get(this, "", "apb_conf", apb_conf_h))
                        `uvm_fatal("APB_MON", "Failed to get APB configuration")
           xtn = apb_xtn::type_id::create("xtn");
        endfunction

        function void connect_phase(uvm_phase phase);
                super.connect_phase(phase);
                vif = apb_conf_h.vif;
        endfunction

        task run_phase(uvm_phase phase);
                forever begin
                        collect();
                end
        endtask

        task collect();
          

           @(vif.apb_mon_cb);
                while( vif.apb_mon_cb.PENABLE !== 1)         // wait for access phase to start
                        @(vif.apb_mon_cb);
        //                @(vif.apb_mon_cb);
                begin
                      while(!vif.apb_mon_cb.PREADY)         // wait for the slave to be ready
                            @(vif.apb_mon_cb);

                            xtn.PADDR = vif.apb_mon_cb.PADDR;
                            xtn.PWRITE = vif.apb_mon_cb.PWRITE;
                            xtn.PREADY = vif.apb_mon_cb.PREADY;
                            xtn.PSLVERR = vif.apb_mon_cb.PSLVERR;
                            xtn.IRQ = vif.apb_mon_cb.IRQ;
                            xtn.PENABLE = vif.apb_mon_cb.PENABLE;
                            xtn.PSEL = vif.apb_mon_cb.PSEL;
                            xtn.PRESETn = vif.apb_mon_cb.PRESETn;

                            if(vif.apb_mon_cb.PWRITE == 1)
                                xtn.PWDATA = vif.apb_mon_cb.PWDATA;
                            else
                                begin
                                //$display(" *****************  storing prdata of vif in xtn.prdata ***********");
                                xtn.PRDATA = vif.apb_mon_cb.PRDATA;
                        //      $display(" ***************** prdata value in xtn is : %0d ***********",xtn.PRDATA);
                                end
                            if(xtn.PADDR == 32'hc && xtn.PWRITE == 1)   xtn.lcr = xtn.PWDATA;
                            if(xtn.PADDR == 32'h4 && xtn.PWRITE == 1)   xtn.ier = xtn.PWDATA;
                            if(xtn.PADDR == 32'h8 && xtn.PWRITE == 1)   xtn.fcr = xtn.PWDATA;

                            if(xtn.PADDR == 32'h8 && xtn.PWRITE == 0)
                                begin
                                    while(!vif.apb_mon_cb.IRQ)                    //wait for the interrupt to be asserted
                                        @(vif.apb_mon_cb);
                                        xtn.iir = vif.apb_mon_cb.PRDATA;

                                end

                                // we will read lsr only when we read iir and if iir value is 6 then only we will read lsr in our sequence so no need to
                                // check the value of iir register here in monitor because we are already checking the value of iir register
                                // in sequence before reading lsr register
                            if(xtn.PADDR == 32'h14 && xtn.PWRITE == 0)  xtn.lsr = xtn.PRDATA;  // no need of condition to check iir becasuse

                            if(xtn.PADDR == 32'h1c && xtn.PWRITE == 1)
                            begin
                                xtn.div[7:0] = xtn.PWDATA;
                                 xtn.dl_access = 1;
                            end
                            if(xtn.PADDR == 32'h20 && xtn.PWRITE == 1)
                            begin
                                xtn.div[15:8] = xtn.PWDATA;
                                 xtn.dl_access = 1;
                            end

                            if(xtn.PADDR == 32'h0 && xtn.PWRITE == 1)
                            begin
                                         xtn.thr.push_back(xtn.PWDATA[7:0]);
                                         xtn.data_in_thr = 1;
                            end

                            if(xtn.PADDR == 32'h0 && xtn.PWRITE == 0)
                            begin
                                         xtn.rbr.push_back(xtn.PRDATA[7:0]);
                                         xtn.data_in_rbr = 1;
                            end

         if (xtn.PADDR == 32'h10 &&
             xtn.PWRITE == 1'b1)
            xtn.mcr = xtn.PWDATA;
                        `uvm_info("APB_MON", "\nSampling is done. Transaction written to port", UVM_MEDIUM)
                        xtn.print();
                        mon_port.write(xtn);
                end
        endtask
endclass
