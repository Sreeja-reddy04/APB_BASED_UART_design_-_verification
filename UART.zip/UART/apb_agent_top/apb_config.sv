class apb_conf extends uvm_object;
        `uvm_object_utils(apb_conf)

        function new(string name = "");
                super.new(name);
        endfunction

        virtual apb_if vif;

endclass
