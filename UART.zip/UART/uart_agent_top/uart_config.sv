class uart_conf extends uvm_object;
        `uvm_object_utils(uart_conf)

        function new(string name = "");
                super.new(name);
        endfunction

        virtual uart_if vif;

endclass
