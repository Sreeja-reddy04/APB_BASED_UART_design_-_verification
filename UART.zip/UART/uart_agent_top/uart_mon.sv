class uart_mon extends uvm_monitor;
        `uvm_component_utils(uart_mon)

        bit[7:0] lcr;
        virtual uart_if vif;
        uart_conf uart_cfg;
        uvm_analysis_port#(uart_xtn) mon_port;
        uart_xtn xtn;

        function new(string name = "",uvm_component parent);
                super.new(name,parent);
        endfunction

        function void build_phase(uvm_phase phase);
                super.build_phase(phase);
                if(!uvm_config_db#(uart_conf)::get(this,"", "uart_conf", uart_cfg))
                        `uvm_fatal("UART_MON", "Failed to get UART interface from config DB")

                if(!uvm_config_db#(bit[7:0])::get(this, "", "lcr", lcr))
                        `uvm_fatal("UART_MON", "Failed to get LCR value from config DB")

                mon_port = new("mon_port", this);
                xtn = uart_xtn::type_id::create("xtn");
        endfunction

        function void connect_phase(uvm_phase phase);
                super.connect_phase(phase);
                vif = uart_cfg.vif;
        endfunction

         task run_phase(uvm_phase phase);
                bit rx_busy, tx_busy;
                fork
                forever
                    begin
                        if(rx_busy == 0)
                           begin
                                rx_busy = 1;   // to avoid sampling of data bits when we are already in middle of receiving a data, we are using this rx_busy signal
                                collect(vif.rx, xtn.rx, xtn.parity); //uart ip core sending bits through tx and we are receiving through rx
                                                                //we will recive bit by bit through rx and we store it in rx of our transaction class(8bit)
                                rx_busy = 0;
                           end
                        else
                                @(posedge vif.baud_o);
                    end

                forever
                     begin
                        if(tx_busy == 0) // start bit of transmitting data
                           begin
                                tx_busy = 1;

                                collect(vif.tx, xtn.tx, xtn.parity);
                                tx_busy = 0;
                           end
                        else
                                @(posedge vif.baud_o);
                     end
                join_none
        endtask

        task collect(ref logic line, ref bit[7:0] data, ref bit parity);
               int bits;
               bits = lcr[1:0]+5;

               /*wait(line==1);
               @(posedge vif.baud_o);
               wait(line==0);    */                     // start bit

                @(negedge line);  // wait for the start bit
                $display("Start bit detected at time %0t", $time);

               repeat(24) @(posedge vif.baud_o);    // wait for the middle of the bit duration

               for(int i=0; i<bits; i++)                //data bits
               begin
                        $display("bit %0d sampled at time %0t", i, $time);
                        data[i] = line;
                        repeat(16) @(posedge vif.baud_o);
               end

               if(lcr[3])
                 begin
                           parity = line;
                           $display("Parity bit sampled at time %0t", $time);
                           repeat(16) @(posedge vif.baud_o);
                 end

                 mon_port.write(xtn);
                 `uvm_info("UART_MON", "\nSampling is done. Transaction written to port", UVM_MEDIUM)
                 xtn.print();

        endtask
endclass

