                         
class env extends uvm_env;
        `uvm_component_utils(env)

        apb_agent_top apb_agent_top_h;
        uart_agent_top uart_agent_top_h;
        sb sbh;
        
        env_conf env_cfg;
        apb_conf apb_cfg;
        uart_conf uart_cfg;

        function new(string name = "",uvm_component parent);
                super.new(name,parent);
        endfunction

        function void build_phase(uvm_phase phase);
                super.build_phase(phase);
                apb_agent_top_h= apb_agent_top::type_id::create("apb_agent_top_h",this);
                uart_agent_top_h= uart_agent_top::type_id::create("uart_agent_top_h",this);

                apb_cfg = apb_conf::type_id::create("apb_cfg");
                uart_cfg = uart_conf::type_id::create("uart_cfg");

                sbh = sb:: type_id::create("sbh",this);
               

                if(!uvm_config_db#(env_conf)::get(this,"", "env_conf", env_cfg))
                        `uvm_fatal("ENV", "Failed to get environment configuration")
                apb_cfg = env_cfg.apb_cfg;
                uart_cfg = env_cfg.uart_cfg;

                uvm_config_db#(apb_conf)::set(this, "apb_agent_top_h*", "apb_conf", apb_cfg);
                uvm_config_db#(uart_conf)::set(this, "uart_agent_top_h*", "uart_conf", uart_cfg);

        endfunction

        function void connect_phase(uvm_phase phase);
                super.connect_phase(phase);
                //vseqrh.apb_seqrh = apb_agent_top_h.apb_agent_h.apb_seqr_h;
                //vseqrh.uart_seqrh = uart_agent_top_h.uart_agent_h.uart_seqr_h;
                        apb_agent_top_h.apb_agent_h.apb_mon_h.mon_port.connect(sbh.apb_fifo.analysis_export);
                        uart_agent_top_h.uart_agent_h.uart_mon_h.mon_port.connect(sbh.uart_fifo.analysis_export);
        endfunction
endclass

