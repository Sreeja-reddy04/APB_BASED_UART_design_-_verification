class env_conf extends uvm_object;
        `uvm_object_utils(env_conf)

        function new(string name = "");
                super.new(name);
        endfunction

        
        uart_conf uart_cfg;
        apb_conf apb_cfg;
endclass